const sosButton = document.getElementById("sosButton");
const sosDialog = document.getElementById("sosDialog");
const closeDialog = document.getElementById("closeDialog");

sosButton.addEventListener("click", () => {
  if (typeof sosDialog.showModal === "function") {
    sosDialog.showModal();
  } else {
    alert("SOS DEMO ONLY: No one has been contacted and no location has been shared.");
  }
});
closeDialog.addEventListener("click", () => sosDialog.close());

const contactForm = document.getElementById("contactForm");
const contactName = document.getElementById("contactName");
const contactList = document.getElementById("contactList");

contactForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const name = contactName.value.trim();
  if (!name) return;

  const item = document.createElement("li");
  const avatar = document.createElement("span");
  avatar.className = "avatar";
  avatar.textContent = name.charAt(0).toUpperCase();

  const details = document.createElement("span");
  const strong = document.createElement("strong");
  strong.textContent = name;
  const small = document.createElement("small");
  small.textContent = "Trusted contact · demo only";
  details.append(strong, small);

  const state = document.createElement("span");
  state.className = "contact-state";
  state.textContent = "Added";

  item.append(avatar, details, state);
  contactList.appendChild(item);
  contactName.value = "";
  contactName.focus();
});

const advice = {
  travel: "Before leaving, check official transit information, choose a public route, keep your phone charged if possible, and let a trusted person know your plan.",
  stranger: "Trust your instincts. Move toward a staffed or busy public place, contact someone you trust, and ask local authorities or staff for help if you feel unsafe.",
  online: "Avoid sharing personal details, save relevant evidence if safe, block and report unwanted contact, and tell a trusted adult or support person if it continues or feels threatening.",
  urgent: "If you may be in immediate danger, move toward a safer public place if possible and contact local emergency services or a trusted person directly. This demo cannot send an alert."
};
document.getElementById("adviceButton").addEventListener("click", () => {
  const choice = document.getElementById("situation").value;
  document.getElementById("adviceBox").textContent = advice[choice];
});

document.getElementById("routeButton").addEventListener("click", () => {
  document.getElementById("routeMessage").textContent =
    "Checklist ready: check official route updates, prefer public well-lit areas, and share your plan with someone you trust. No live route has been checked.";
});
