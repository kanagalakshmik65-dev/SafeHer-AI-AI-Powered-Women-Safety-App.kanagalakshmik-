# SafeHer AI — AI-Powered Women Safety App

A hackathon-ready **web prototype** for a women-safety support app. It demonstrates an emergency alert flow, trusted contacts, safety tips, and route-planning guidance in a responsive interface.

> **Important safety note:** This is a demo prototype, not a certified emergency service. The SOS action in this version only shows a local demo confirmation; it does **not** send SMS/calls or share live location. Do not rely on this prototype during a real emergency.

## Features
- Emergency SOS demo button with clear confirmation
- Trusted contacts list (editable in the interface for the current session)
- Safety tips and quick-access emergency guidance
- Route-planning guidance (not a live navigation or safety guarantee)
- Responsive design for mobile and desktop
- No API keys or external backend required

## Tech stack
- HTML
- CSS
- Vanilla JavaScript

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern browser.

No installation or build step is required.

## Upload to GitHub
1. Create a new GitHub repository named `safeher-ai`.
2. Choose **Add file → Upload files**.
3. Upload `index.html`, `style.css`, `script.js`, and `README.md` (or upload the ZIP contents).
4. Select **Commit changes**.
5. Optional: go to **Settings → Pages**, select the `main` branch and `/ (root)` folder, then save to publish the demo website.

## Suggested hackathon presentation
1. Explain the problem: reaching trusted people quickly can be difficult in stressful situations.
2. Demonstrate the SOS prototype and trusted contacts UI.
3. Explain how a production version could integrate verified emergency-service APIs, opt-in location sharing, accessibility features, privacy protections, and secure backend infrastructure.
4. Be transparent that the current version is a front-end demo.

## Before production
A real safety product needs threat modelling, privacy review, consent-based location sharing, secure authentication, abuse prevention, reliable alert delivery, regional emergency-number verification, testing on real devices, and partnerships with qualified service providers. Never claim an alert was sent unless the backend confirms delivery.
